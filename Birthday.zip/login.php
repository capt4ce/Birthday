<!DOCTYPE html>
<!--This website is made just for fun :p
Fabricated by: Ahmad Ali Abdilah
For Anusha, HAPPY BIRTHDAY!!
Hope you like this small piece of work :D :D
-->
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE= edge">
    <meta name="viewport" content="width-device-width, initial-scale-1"><link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
    <title>Wish</title>
  </head>
  <body id="login">
    <div class="row" style="margin-top: 30px">
      <div class="col-md-4 col-md-offset-4 text-center">
        <div class="panel" id="back"></div>
        <div class="panel">
          <h3>Login</h3>
          <hr width="50%"><br>
          <form method="post" action="functionalities/process_login.php">
            <div class="form-group">
              <div class="input-group col-xs-8 col-xs-offset-2"><span class="input-group-addon">@</span>
                <input class="form-control" id="uName" type="text" placeholder="Username" name="uName">
              </div><br>
              <div class="input-group col-xs-8 col-xs-offset-2"><span class="input-group-addon">***</span>
                <input class="form-control" id="pWord" type="password" placeholder="Password" name="pWord">
              </div><br>
              <button class="btn btn-primary" type="submit">Login</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </body>
</html>
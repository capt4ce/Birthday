//delete install.php file

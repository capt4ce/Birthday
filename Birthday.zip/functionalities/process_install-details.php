<?php

  delete('../install.php');
?>

<!DOCTYPE html>
<!--This website is made just for fun :p
Fabricated by: Ahmad Ali Abdilah
For Anusha, HAPPY BIRTHDAY!!
Hope you like this small piece of work :D :D
-->
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE= edge">
    <meta name="viewport" content="width-device-width, initial-scale-1"><link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
    <title>About</title>
  </head>
  <body id="about-panel">
    <div class="row text-center">
      <div class="col-md-4 col-md-offset-4">
        <div class="panel panel-default" style="padding: 20px; margin-top: 50px">
          <div class="pic-section">
            <div class="profile-pic">
              <!--img(src="")-->
            </div>
          </div>
          <div class="comment-section text-center">
            <div class="ribbon"></div>
            <h4>Ahmad Ali Abdilah</h4><br>
            <p>
              A curious-driven person. A noob web-developer, programmer and designer.
              Passionate about technology but hate studying :p
              Love to have light chit-chat and small discussion.
            </p>
          </div>
        </div>
      </div>
      <div class="col-md-12"><br><br><a href="index.php" id="home">
          <div class="glyphicon glyphicon-home"></div></a></div>
    </div>
  </body>
</html>
<?php $path="functionalities/"; $page="album"; include("functionalities/functions.php");?><!DOCTYPE html>
<!--This website is made just for fun :p
Fabricated by: Ahmad Ali Abdilah
For Anusha, HAPPY BIRTHDAY!!
Hope you like this small piece of work :D :D
-->
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE= edge">
    <meta name="viewport" content="width-device-width, initial-scale-1"><link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
    <title>Album</title>
  </head>
  <body>
    <div class="row">
    <div class="col-md-3">
    <img src="themes/fancy/src/background.jpg" class="img-thumbnail">
  </div>
  <div class="col-md-3">
  <img src="themes/fancy/src/background.jpg" class="img-thumbnail">
</div>
<div class="col-md-3">
<img src="themes/fancy/src/background.jpg" class="img-thumbnail">
</div>
<div class="col-md-3">
<img src="themes/fancy/src/background.jpg" class="img-thumbnail">
</div>
  </div>
  </body>
</html>
